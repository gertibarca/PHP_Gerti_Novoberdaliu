# Més Que Un Project - FC Barcelona Fan Portal

## Overview
A modern, object-oriented PHP 8.4+ web application built with MVC architecture for FC Barcelona fans. Features match tracking, squad management, news CRUD, and membership system.

## Project Architecture

### Tech Stack
- **Backend**: PHP 8.4+ with vanilla MVC architecture
- **Database**: PostgreSQL with PDO (prepared statements)
- **Frontend**: Tailwind CSS via CDN with Barça colors (Blaugrana: #A50044 and #004D98)
- **Dependencies**: Composer with vlucas/phpdotenv

### Directory Structure
```
├── app/
│   ├── Controllers/     # Request handlers (HomeController, MatchController, etc.)
│   ├── Models/          # Database models (User, Player, GameMatch, News)
│   └── Core/            # Framework core (Database, Controller, Router)
├── views/
│   ├── layouts/         # Header and footer templates
│   ├── home/            # Homepage view
│   ├── matches/         # Match day dashboard views
│   ├── squad/           # Squad page views
│   ├── news/            # News CRUD views
│   └── auth/            # Login/Register views
├── public/
│   ├── index.php        # Front controller / Router
│   ├── css/             # Custom stylesheets
│   └── assets/          # Static assets
├── vendor/              # Composer dependencies
└── composer.json        # Dependency management
```

### Core Features
1. **Match Day Dashboard**: Shows next fixture and recent results
2. **Squad Page**: Lists players by position with kit numbers
3. **Barça News**: Full CRUD system for blog posts (admin only)
4. **Membership System**: User registration and login with secure password hashing

### Database Schema
- `users`: User accounts with admin flag
- `players`: Player roster with position and kit number
- `matches`: Match fixtures and results
- `news`: News articles with author relationship

### Security Features
- PDO prepared statements (SQL injection protection)
- htmlspecialchars output (XSS prevention)
- Password hashing with bcrypt
- Session-based authentication

## Running the Application
The application runs on PHP's built-in development server:
```bash
php -S 0.0.0.0:5000 -t public
```

## Admin Access
- Email: admin@barca.com
- Password: password (bcrypt hashed)

## Recent Changes
- January 31, 2026: Initial project setup with all core features
  - Created MVC architecture with PHP 8.4
  - Implemented all four core features
  - Added sample data (players, matches, news)
  - Styled with Tailwind CSS and FC Barcelona colors
