<?php

namespace App\Core;

class Router
{
    private array $routes = [];

    public function get(string $path, array $handler): self
    {
        $this->routes['GET'][$path] = $handler;
        return $this;
    }

    public function post(string $path, array $handler): self
    {
        $this->routes['POST'][$path] = $handler;
        return $this;
    }

    public function dispatch(): void
    {
        $method = $_SERVER['REQUEST_METHOD'];
        $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $uri = rtrim($uri, '/') ?: '/';

        foreach ($this->routes[$method] ?? [] as $route => $handler) {
            $pattern = $this->convertToRegex($route);
            
            if (preg_match($pattern, $uri, $matches)) {
                array_shift($matches);
                
                [$controllerClass, $action] = $handler;
                
                if (!class_exists($controllerClass)) {
                    throw new \Exception("Controller not found: {$controllerClass}");
                }

                $controller = new $controllerClass();
                
                if (!method_exists($controller, $action)) {
                    throw new \Exception("Action not found: {$action}");
                }

                call_user_func_array([$controller, $action], $matches);
                return;
            }
        }

        http_response_code(404);
        echo $this->render404();
    }

    private function convertToRegex(string $route): string
    {
        $pattern = preg_replace('/\{([a-zA-Z_]+)\}/', '([^/]+)', $route);
        return '#^' . $pattern . '$#';
    }

    private function render404(): string
    {
        return '
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>404 - Page Not Found</title>
            <script src="https://cdn.tailwindcss.com"></script>
        </head>
        <body class="bg-gray-100 min-h-screen flex items-center justify-center">
            <div class="text-center">
                <h1 class="text-6xl font-bold text-[#A50044]">404</h1>
                <p class="text-xl text-gray-600 mt-4">Page not found</p>
                <a href="/" class="mt-6 inline-block bg-[#004D98] text-white px-6 py-3 rounded-lg hover:bg-[#003d7a] transition">
                    Return Home
                </a>
            </div>
        </body>
        </html>';
    }
}
