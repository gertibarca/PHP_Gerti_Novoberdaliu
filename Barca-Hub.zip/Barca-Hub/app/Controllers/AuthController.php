<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Models\User;

class AuthController extends Controller
{
    public function loginForm(): void
    {
        if ($this->isAuthenticated()) {
            $this->redirect('/');
            return;
        }

        $this->view('auth/login', [
            'pageTitle' => 'Login - Més Que Un Project',
            'user' => null,
        ]);
    }

    public function login(): void
    {
        $email = $this->sanitize($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($email) || empty($password)) {
            $_SESSION['error'] = 'Email and password are required';
            $this->redirect('/login');
            return;
        }

        $user = User::findByEmail($email);

        if (!$user || !User::verifyPassword($password, $user['password'])) {
            $_SESSION['error'] = 'Invalid email or password';
            $this->redirect('/login');
            return;
        }

        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['is_admin'] = (bool) $user['is_admin'];

        $_SESSION['success'] = 'Welcome back, ' . $user['username'] . '!';
        $this->redirect('/');
    }

    public function registerForm(): void
    {
        if ($this->isAuthenticated()) {
            $this->redirect('/');
            return;
        }

        $this->view('auth/register', [
            'pageTitle' => 'Register - Més Que Un Project',
            'user' => null,
        ]);
    }

    public function register(): void
    {
        $username = $this->sanitize($_POST['username'] ?? '');
        $email = $this->sanitize($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';

        if (empty($username) || empty($email) || empty($password)) {
            $_SESSION['error'] = 'All fields are required';
            $this->redirect('/register');
            return;
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['error'] = 'Please enter a valid email address';
            $this->redirect('/register');
            return;
        }

        if (strlen($password) < 6) {
            $_SESSION['error'] = 'Password must be at least 6 characters';
            $this->redirect('/register');
            return;
        }

        if ($password !== $confirmPassword) {
            $_SESSION['error'] = 'Passwords do not match';
            $this->redirect('/register');
            return;
        }

        if (User::findByEmail($email)) {
            $_SESSION['error'] = 'Email already exists';
            $this->redirect('/register');
            return;
        }

        if (User::findByUsername($username)) {
            $_SESSION['error'] = 'Username already exists';
            $this->redirect('/register');
            return;
        }

        $userId = User::create([
            'username' => $username,
            'email' => $email,
            'password' => $password,
            'is_admin' => false,
        ]);

        $_SESSION['user_id'] = $userId;
        $_SESSION['username'] = $username;
        $_SESSION['email'] = $email;
        $_SESSION['is_admin'] = false;

        $_SESSION['success'] = 'Registration successful! Welcome to the Barça family!';
        $this->redirect('/');
    }

    public function logout(): void
    {
        session_destroy();
        session_start();
        $_SESSION['success'] = 'You have been logged out';
        $this->redirect('/');
    }
}
