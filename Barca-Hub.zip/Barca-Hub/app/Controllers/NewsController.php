<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Models\News;

class NewsController extends Controller
{
    public function index(): void
    {
        $news = News::all();

        $this->view('news/index', [
            'pageTitle' => 'Barça News - Més Que Un Project',
            'news' => $news,
            'user' => $this->getSessionUser(),
        ]);
    }

    public function show(string $id): void
    {
        $article = News::findById((int) $id);

        if (!$article) {
            $this->redirect('/news');
            return;
        }

        $this->view('news/show', [
            'pageTitle' => $article['title'] . ' - Més Que Un Project',
            'article' => $article,
            'user' => $this->getSessionUser(),
        ]);
    }

    public function create(): void
    {
        $this->requireAdmin();

        $this->view('news/create', [
            'pageTitle' => 'Create News Article - Més Que Un Project',
            'user' => $this->getSessionUser(),
        ]);
    }

    public function store(): void
    {
        $this->requireAdmin();

        $title = $this->sanitize($_POST['title'] ?? '');
        $content = $_POST['content'] ?? '';
        $excerpt = $this->sanitize($_POST['excerpt'] ?? '');
        $imageUrl = $this->sanitize($_POST['image_url'] ?? '');

        if (empty($title) || empty($content)) {
            $_SESSION['error'] = 'Title and content are required';
            $this->redirect('/news/create');
            return;
        }

        News::create([
            'title' => $title,
            'content' => $content,
            'excerpt' => $excerpt,
            'author_id' => $_SESSION['user_id'],
            'image_url' => $imageUrl,
        ]);

        $_SESSION['success'] = 'Article created successfully';
        $this->redirect('/news');
    }

    public function edit(string $id): void
    {
        $this->requireAdmin();

        $article = News::findById((int) $id);

        if (!$article) {
            $this->redirect('/news');
            return;
        }

        $this->view('news/edit', [
            'pageTitle' => 'Edit Article - Més Que Un Project',
            'article' => $article,
            'user' => $this->getSessionUser(),
        ]);
    }

    public function update(string $id): void
    {
        $this->requireAdmin();

        $title = $this->sanitize($_POST['title'] ?? '');
        $content = $_POST['content'] ?? '';
        $excerpt = $this->sanitize($_POST['excerpt'] ?? '');
        $imageUrl = $this->sanitize($_POST['image_url'] ?? '');

        if (empty($title) || empty($content)) {
            $_SESSION['error'] = 'Title and content are required';
            $this->redirect("/news/{$id}/edit");
            return;
        }

        News::update((int) $id, [
            'title' => $title,
            'content' => $content,
            'excerpt' => $excerpt,
            'image_url' => $imageUrl,
        ]);

        $_SESSION['success'] = 'Article updated successfully';
        $this->redirect('/news/' . $id);
    }

    public function delete(string $id): void
    {
        $this->requireAdmin();

        News::delete((int) $id);
        
        $_SESSION['success'] = 'Article deleted successfully';
        $this->redirect('/news');
    }
}
