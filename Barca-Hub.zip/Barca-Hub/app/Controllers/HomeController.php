<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Models\GameMatch;
use App\Models\News;

class HomeController extends Controller
{
    public function index(): void
    {
        $nextMatch = GameMatch::getNextFixture();
        $recentResults = GameMatch::getRecentResults(3);
        $latestNews = News::getLatest(3);

        $this->view('home/index', [
            'pageTitle' => 'Més Que Un Project - FC Barcelona Fan Portal',
            'nextMatch' => $nextMatch,
            'recentResults' => $recentResults,
            'latestNews' => $latestNews,
            'user' => $this->getSessionUser(),
        ]);
    }
}
