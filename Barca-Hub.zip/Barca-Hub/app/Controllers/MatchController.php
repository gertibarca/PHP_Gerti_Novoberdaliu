<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Models\GameMatch;

class MatchController extends Controller
{
    public function index(): void
    {
        $nextMatch = GameMatch::getNextFixture();
        $recentResults = GameMatch::getRecentResults(10);
        $allMatches = GameMatch::all();

        $this->view('matches/index', [
            'pageTitle' => 'Match Day Dashboard - Més Que Un Project',
            'nextMatch' => $nextMatch,
            'recentResults' => $recentResults,
            'allMatches' => $allMatches,
            'user' => $this->getSessionUser(),
        ]);
    }
}
