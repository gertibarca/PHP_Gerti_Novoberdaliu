<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Models\Player;

class SquadController extends Controller
{
    public function index(): void
    {
        $players = Player::all();
        
        $grouped = [
            'Goalkeeper' => [],
            'Defender' => [],
            'Midfielder' => [],
            'Forward' => [],
        ];

        foreach ($players as $player) {
            $position = $player['position'] ?? 'Other';
            if (isset($grouped[$position])) {
                $grouped[$position][] = $player;
            }
        }

        $this->view('squad/index', [
            'pageTitle' => 'Squad - Més Que Un Project',
            'players' => $players,
            'groupedPlayers' => $grouped,
            'user' => $this->getSessionUser(),
        ]);
    }
}
