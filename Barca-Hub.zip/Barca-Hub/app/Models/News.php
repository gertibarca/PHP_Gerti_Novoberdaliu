<?php

namespace App\Models;

use App\Core\Database;

class News
{
    public static function all(): array
    {
        $sql = "SELECT n.*, u.username as author_name 
                FROM news n 
                LEFT JOIN users u ON n.author_id = u.id 
                ORDER BY n.created_at DESC";
        return Database::query($sql)->fetchAll();
    }

    public static function findById(int $id): ?array
    {
        $sql = "SELECT n.*, u.username as author_name 
                FROM news n 
                LEFT JOIN users u ON n.author_id = u.id 
                WHERE n.id = :id LIMIT 1";
        $stmt = Database::query($sql, ['id' => $id]);
        $news = $stmt->fetch();
        
        return $news ?: null;
    }

    public static function getLatest(int $limit = 5): array
    {
        $sql = "SELECT n.*, u.username as author_name 
                FROM news n 
                LEFT JOIN users u ON n.author_id = u.id 
                ORDER BY n.created_at DESC LIMIT :limit";
        return Database::query($sql, ['limit' => $limit])->fetchAll();
    }

    public static function create(array $data): int
    {
        $sql = "INSERT INTO news (title, content, excerpt, author_id, image_url, created_at, updated_at) 
                VALUES (:title, :content, :excerpt, :author_id, :image_url, NOW(), NOW())";
        
        Database::query($sql, [
            'title' => $data['title'],
            'content' => $data['content'],
            'excerpt' => $data['excerpt'] ?? substr(strip_tags($data['content']), 0, 200),
            'author_id' => $data['author_id'],
            'image_url' => $data['image_url'] ?? '',
        ]);

        return (int) Database::lastInsertId();
    }

    public static function update(int $id, array $data): bool
    {
        $sql = "UPDATE news SET title = :title, content = :content, excerpt = :excerpt, 
                image_url = :image_url, updated_at = NOW() WHERE id = :id";
        
        Database::query($sql, [
            'id' => $id,
            'title' => $data['title'],
            'content' => $data['content'],
            'excerpt' => $data['excerpt'] ?? substr(strip_tags($data['content']), 0, 200),
            'image_url' => $data['image_url'] ?? '',
        ]);

        return true;
    }

    public static function delete(int $id): bool
    {
        $sql = "DELETE FROM news WHERE id = :id";
        Database::query($sql, ['id' => $id]);
        return true;
    }
}
