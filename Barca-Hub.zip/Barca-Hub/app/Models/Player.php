<?php

namespace App\Models;

use App\Core\Database;

class Player
{
    public static function all(): array
    {
        $sql = "SELECT * FROM players ORDER BY position, kit_number ASC";
        return Database::query($sql)->fetchAll();
    }

    public static function findById(int $id): ?array
    {
        $sql = "SELECT * FROM players WHERE id = :id LIMIT 1";
        $stmt = Database::query($sql, ['id' => $id]);
        $player = $stmt->fetch();
        
        return $player ?: null;
    }

    public static function create(array $data): int
    {
        $sql = "INSERT INTO players (name, position, kit_number, nationality, image_url, created_at) 
                VALUES (:name, :position, :kit_number, :nationality, :image_url, NOW())";
        
        Database::query($sql, [
            'name' => $data['name'],
            'position' => $data['position'],
            'kit_number' => $data['kit_number'],
            'nationality' => $data['nationality'] ?? '',
            'image_url' => $data['image_url'] ?? '',
        ]);

        return (int) Database::lastInsertId();
    }

    public static function update(int $id, array $data): bool
    {
        $sql = "UPDATE players SET name = :name, position = :position, kit_number = :kit_number, 
                nationality = :nationality, image_url = :image_url WHERE id = :id";
        
        Database::query($sql, [
            'id' => $id,
            'name' => $data['name'],
            'position' => $data['position'],
            'kit_number' => $data['kit_number'],
            'nationality' => $data['nationality'] ?? '',
            'image_url' => $data['image_url'] ?? '',
        ]);

        return true;
    }

    public static function delete(int $id): bool
    {
        $sql = "DELETE FROM players WHERE id = :id";
        Database::query($sql, ['id' => $id]);
        return true;
    }

    public static function getByPosition(string $position): array
    {
        $sql = "SELECT * FROM players WHERE position = :position ORDER BY kit_number ASC";
        return Database::query($sql, ['position' => $position])->fetchAll();
    }
}
