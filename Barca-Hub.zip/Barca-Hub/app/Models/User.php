<?php

namespace App\Models;

use App\Core\Database;

class User
{
    public static function create(array $data): int
    {
        $sql = "INSERT INTO users (username, email, password, is_admin, created_at) 
                VALUES (:username, :email, :password, :is_admin, NOW())";
        
        Database::query($sql, [
            'username' => $data['username'],
            'email' => $data['email'],
            'password' => password_hash($data['password'], PASSWORD_BCRYPT),
            'is_admin' => $data['is_admin'] ?? false,
        ]);

        return (int) Database::lastInsertId();
    }

    public static function findByEmail(string $email): ?array
    {
        $sql = "SELECT * FROM users WHERE email = :email LIMIT 1";
        $stmt = Database::query($sql, ['email' => $email]);
        $user = $stmt->fetch();
        
        return $user ?: null;
    }

    public static function findById(int $id): ?array
    {
        $sql = "SELECT * FROM users WHERE id = :id LIMIT 1";
        $stmt = Database::query($sql, ['id' => $id]);
        $user = $stmt->fetch();
        
        return $user ?: null;
    }

    public static function findByUsername(string $username): ?array
    {
        $sql = "SELECT * FROM users WHERE username = :username LIMIT 1";
        $stmt = Database::query($sql, ['username' => $username]);
        $user = $stmt->fetch();
        
        return $user ?: null;
    }

    public static function verifyPassword(string $password, string $hash): bool
    {
        return password_verify($password, $hash);
    }

    public static function all(): array
    {
        $sql = "SELECT id, username, email, is_admin, created_at FROM users ORDER BY created_at DESC";
        return Database::query($sql)->fetchAll();
    }
}
