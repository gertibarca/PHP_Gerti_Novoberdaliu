<?php

namespace App\Models;

use App\Core\Database;

class GameMatch
{
    public static function all(): array
    {
        $sql = "SELECT * FROM matches ORDER BY match_date DESC";
        return Database::query($sql)->fetchAll();
    }

    public static function findById(int $id): ?array
    {
        $sql = "SELECT * FROM matches WHERE id = :id LIMIT 1";
        $stmt = Database::query($sql, ['id' => $id]);
        $match = $stmt->fetch();
        
        return $match ?: null;
    }

    public static function getNextFixture(): ?array
    {
        $sql = "SELECT * FROM matches WHERE match_date >= CURRENT_DATE AND status = 'upcoming' 
                ORDER BY match_date ASC LIMIT 1";
        $stmt = Database::query($sql);
        $match = $stmt->fetch();
        
        return $match ?: null;
    }

    public static function getRecentResults(int $limit = 5): array
    {
        $sql = "SELECT * FROM matches WHERE status = 'completed' 
                ORDER BY match_date DESC LIMIT :limit";
        return Database::query($sql, ['limit' => $limit])->fetchAll();
    }

    public static function create(array $data): int
    {
        $sql = "INSERT INTO matches (opponent, match_date, venue, competition, home_score, away_score, status, created_at) 
                VALUES (:opponent, :match_date, :venue, :competition, :home_score, :away_score, :status, NOW())";
        
        Database::query($sql, [
            'opponent' => $data['opponent'],
            'match_date' => $data['match_date'],
            'venue' => $data['venue'],
            'competition' => $data['competition'] ?? 'La Liga',
            'home_score' => $data['home_score'] ?? null,
            'away_score' => $data['away_score'] ?? null,
            'status' => $data['status'] ?? 'upcoming',
        ]);

        return (int) Database::lastInsertId();
    }

    public static function update(int $id, array $data): bool
    {
        $sql = "UPDATE matches SET opponent = :opponent, match_date = :match_date, venue = :venue, 
                competition = :competition, home_score = :home_score, away_score = :away_score, 
                status = :status WHERE id = :id";
        
        Database::query($sql, [
            'id' => $id,
            'opponent' => $data['opponent'],
            'match_date' => $data['match_date'],
            'venue' => $data['venue'],
            'competition' => $data['competition'],
            'home_score' => $data['home_score'],
            'away_score' => $data['away_score'],
            'status' => $data['status'],
        ]);

        return true;
    }

    public static function delete(int $id): bool
    {
        $sql = "DELETE FROM matches WHERE id = :id";
        Database::query($sql, ['id' => $id]);
        return true;
    }
}
