<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle ?? 'Més Que Un Project') ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'barca-red': '#A50044',
                        'barca-blue': '#004D98',
                        'barca-gold': '#EDBB00',
                    }
                }
            }
        }
    </script>
    <link rel="stylesheet" href="/css/custom.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Montserrat', sans-serif; }
    </style>
</head>
<body class="bg-gray-50 min-h-screen flex flex-col">
    <header class="bg-gradient-to-r from-barca-blue to-barca-red shadow-lg sticky top-0 z-50">
        <nav class="container mx-auto px-4 py-3">
            <div class="flex items-center justify-between">
                <a href="/" class="flex items-center space-x-3 group">
                    <div class="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-md group-hover:shadow-lg transition">
                        <svg viewBox="0 0 100 100" class="w-10 h-10">
                            <circle cx="50" cy="50" r="48" fill="#A50044"/>
                            <circle cx="50" cy="50" r="40" fill="#004D98"/>
                            <text x="50" y="58" text-anchor="middle" fill="white" font-size="24" font-weight="bold">FCB</text>
                        </svg>
                    </div>
                    <div class="text-white">
                        <span class="text-xl font-bold tracking-tight">Més Que Un Project</span>
                        <span class="block text-xs text-yellow-300 font-medium">FC Barcelona Fan Portal</span>
                    </div>
                </a>

                <div class="hidden md:flex items-center space-x-1">
                    <a href="/" class="px-4 py-2 text-white hover:bg-white/10 rounded-lg transition font-medium">Home</a>
                    <a href="/matches" class="px-4 py-2 text-white hover:bg-white/10 rounded-lg transition font-medium">Match Day</a>
                    <a href="/squad" class="px-4 py-2 text-white hover:bg-white/10 rounded-lg transition font-medium">Squad</a>
                    <a href="/news" class="px-4 py-2 text-white hover:bg-white/10 rounded-lg transition font-medium">News</a>
                    
                    <?php if (isset($user) && $user): ?>
                        <div class="flex items-center space-x-2 ml-4 pl-4 border-l border-white/30">
                            <span class="text-white/80 text-sm">Welcome, <?= htmlspecialchars($user['username']) ?></span>
                            <?php if ($user['is_admin']): ?>
                                <span class="bg-barca-gold text-barca-blue text-xs px-2 py-1 rounded font-bold">ADMIN</span>
                            <?php endif; ?>
                            <a href="/logout" class="bg-white text-barca-red px-4 py-2 rounded-lg font-semibold hover:bg-gray-100 transition">
                                Logout
                            </a>
                        </div>
                    <?php else: ?>
                        <div class="flex items-center space-x-2 ml-4 pl-4 border-l border-white/30">
                            <a href="/login" class="px-4 py-2 text-white hover:bg-white/10 rounded-lg transition font-medium">Login</a>
                            <a href="/register" class="bg-barca-gold text-barca-blue px-4 py-2 rounded-lg font-semibold hover:bg-yellow-400 transition">
                                Join Now
                            </a>
                        </div>
                    <?php endif; ?>
                </div>

                <button id="mobile-menu-btn" class="md:hidden text-white p-2">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
                    </svg>
                </button>
            </div>

            <div id="mobile-menu" class="hidden md:hidden mt-4 pb-4 border-t border-white/20 pt-4">
                <div class="flex flex-col space-y-2">
                    <a href="/" class="px-4 py-2 text-white hover:bg-white/10 rounded-lg transition">Home</a>
                    <a href="/matches" class="px-4 py-2 text-white hover:bg-white/10 rounded-lg transition">Match Day</a>
                    <a href="/squad" class="px-4 py-2 text-white hover:bg-white/10 rounded-lg transition">Squad</a>
                    <a href="/news" class="px-4 py-2 text-white hover:bg-white/10 rounded-lg transition">News</a>
                    <?php if (isset($user) && $user): ?>
                        <a href="/logout" class="px-4 py-2 text-white hover:bg-white/10 rounded-lg transition">Logout</a>
                    <?php else: ?>
                        <a href="/login" class="px-4 py-2 text-white hover:bg-white/10 rounded-lg transition">Login</a>
                        <a href="/register" class="px-4 py-2 bg-barca-gold text-barca-blue rounded-lg font-semibold text-center">Join Now</a>
                    <?php endif; ?>
                </div>
            </div>
        </nav>
    </header>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 container mx-auto mt-4 rounded" role="alert">
            <p><?= htmlspecialchars($_SESSION['success']) ?></p>
        </div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>

    <?php if (isset($_SESSION['error'])): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 container mx-auto mt-4 rounded" role="alert">
            <p><?= htmlspecialchars($_SESSION['error']) ?></p>
        </div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <main class="flex-grow">
