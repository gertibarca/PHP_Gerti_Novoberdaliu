<?php require dirname(__DIR__) . '/layouts/header.php'; ?>

<section class="bg-gradient-to-r from-barca-blue to-barca-red py-12">
    <div class="container mx-auto px-4">
        <div class="flex items-center justify-between">
            <div class="text-white">
                <h1 class="text-4xl font-extrabold mb-2">Barça News</h1>
                <p class="text-white/80">The latest updates from Camp Nou</p>
            </div>
            <?php if (isset($user) && $user && $user['is_admin']): ?>
                <a href="/news/create" class="bg-barca-gold text-barca-blue px-6 py-3 rounded-lg font-bold hover:bg-yellow-400 transition shadow-lg">
                    + New Article
                </a>
            <?php endif; ?>
        </div>
    </div>
</section>

<section class="py-12 container mx-auto px-4">
    <?php if (!empty($news)): ?>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <?php foreach ($news as $article): ?>
                <article class="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition group">
                    <div class="h-52 bg-gradient-to-br from-barca-blue to-barca-red flex items-center justify-center relative">
                        <?php if (!empty($article['image_url'])): ?>
                            <img src="<?= htmlspecialchars($article['image_url']) ?>" alt="" class="w-full h-full object-cover">
                        <?php else: ?>
                            <svg class="w-20 h-20 text-white/30" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"/>
                            </svg>
                        <?php endif; ?>
                    </div>
                    <div class="p-6">
                        <div class="flex items-center justify-between mb-3">
                            <span class="text-sm text-gray-500"><?= date('F j, Y', strtotime($article['created_at'])) ?></span>
                            <?php if (!empty($article['author_name'])): ?>
                                <span class="text-xs text-barca-blue font-medium">By <?= htmlspecialchars($article['author_name']) ?></span>
                            <?php endif; ?>
                        </div>
                        <h3 class="text-xl font-bold text-gray-800 mb-3 group-hover:text-barca-blue transition line-clamp-2">
                            <?= htmlspecialchars($article['title']) ?>
                        </h3>
                        <p class="text-gray-600 text-sm mb-4 line-clamp-3">
                            <?= htmlspecialchars($article['excerpt'] ?? substr(strip_tags($article['content']), 0, 150)) ?>...
                        </p>
                        <div class="flex items-center justify-between">
                            <a href="/news/<?= $article['id'] ?>" class="text-barca-red font-semibold hover:text-barca-blue transition inline-flex items-center">
                                Read More
                                <svg class="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                                </svg>
                            </a>
                            <?php if (isset($user) && $user && $user['is_admin']): ?>
                                <div class="flex space-x-2">
                                    <a href="/news/<?= $article['id'] ?>/edit" class="text-gray-400 hover:text-barca-blue transition">
                                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                                        </svg>
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="text-center py-16 text-gray-500">
            <svg class="w-24 h-24 mx-auto mb-6 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"/>
            </svg>
            <h3 class="text-xl font-semibold text-gray-600 mb-2">No news articles yet</h3>
            <p class="text-gray-400">Check back soon for the latest updates from Camp Nou.</p>
        </div>
    <?php endif; ?>
</section>

<?php require dirname(__DIR__) . '/layouts/footer.php'; ?>
