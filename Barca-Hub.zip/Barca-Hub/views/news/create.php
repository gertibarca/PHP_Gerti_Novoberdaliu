<?php require dirname(__DIR__) . '/layouts/header.php'; ?>

<section class="bg-gradient-to-r from-barca-blue to-barca-red py-12">
    <div class="container mx-auto px-4">
        <h1 class="text-4xl font-extrabold text-white mb-2">Create New Article</h1>
        <p class="text-white/80">Share the latest news with the Barça community</p>
    </div>
</section>

<section class="py-12 container mx-auto px-4 max-w-3xl">
    <div class="bg-white rounded-2xl shadow-xl p-8">
        <form action="/news/store" method="POST">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">
            <div class="mb-6">
                <label for="title" class="block text-sm font-semibold text-gray-700 mb-2">Article Title</label>
                <input type="text" id="title" name="title" required
                    class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-barca-blue focus:ring-2 focus:ring-barca-blue/20 outline-none transition"
                    placeholder="Enter the article title">
            </div>

            <div class="mb-6">
                <label for="excerpt" class="block text-sm font-semibold text-gray-700 mb-2">Excerpt (Optional)</label>
                <input type="text" id="excerpt" name="excerpt"
                    class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-barca-blue focus:ring-2 focus:ring-barca-blue/20 outline-none transition"
                    placeholder="Brief summary of the article">
            </div>

            <div class="mb-6">
                <label for="image_url" class="block text-sm font-semibold text-gray-700 mb-2">Image URL (Optional)</label>
                <input type="url" id="image_url" name="image_url"
                    class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-barca-blue focus:ring-2 focus:ring-barca-blue/20 outline-none transition"
                    placeholder="https://example.com/image.jpg">
            </div>

            <div class="mb-8">
                <label for="content" class="block text-sm font-semibold text-gray-700 mb-2">Content</label>
                <textarea id="content" name="content" rows="12" required
                    class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-barca-blue focus:ring-2 focus:ring-barca-blue/20 outline-none transition resize-y"
                    placeholder="Write your article content here..."></textarea>
            </div>

            <div class="flex items-center justify-between">
                <a href="/news" class="text-gray-600 hover:text-gray-800 transition">Cancel</a>
                <button type="submit" class="bg-gradient-to-r from-barca-blue to-barca-red text-white px-8 py-3 rounded-lg font-bold hover:opacity-90 transition shadow-lg">
                    Publish Article
                </button>
            </div>
        </form>
    </div>
</section>

<?php require dirname(__DIR__) . '/layouts/footer.php'; ?>
