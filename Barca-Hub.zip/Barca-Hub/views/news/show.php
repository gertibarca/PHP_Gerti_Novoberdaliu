<?php require dirname(__DIR__) . '/layouts/header.php'; ?>

<article class="py-12">
    <div class="container mx-auto px-4 max-w-4xl">
        <a href="/news" class="inline-flex items-center text-barca-blue hover:text-barca-red transition mb-6">
            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
            </svg>
            Back to News
        </a>

        <?php if (!empty($article['image_url'])): ?>
            <div class="h-80 rounded-2xl overflow-hidden mb-8">
                <img src="<?= htmlspecialchars($article['image_url']) ?>" alt="" class="w-full h-full object-cover">
            </div>
        <?php else: ?>
            <div class="h-64 bg-gradient-to-br from-barca-blue to-barca-red rounded-2xl mb-8 flex items-center justify-center">
                <svg class="w-24 h-24 text-white/30" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"/>
                </svg>
            </div>
        <?php endif; ?>

        <div class="flex items-center justify-between mb-6">
            <div class="flex items-center space-x-4">
                <span class="text-gray-500"><?= date('F j, Y', strtotime($article['created_at'])) ?></span>
                <?php if (!empty($article['author_name'])): ?>
                    <span class="text-barca-blue font-medium">By <?= htmlspecialchars($article['author_name']) ?></span>
                <?php endif; ?>
            </div>
            <?php if (isset($user) && $user && $user['is_admin']): ?>
                <div class="flex space-x-3">
                    <a href="/news/<?= $article['id'] ?>/edit" class="bg-barca-blue text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-800 transition inline-flex items-center">
                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                        </svg>
                        Edit
                    </a>
                    <form action="/news/<?= $article['id'] ?>/delete" method="POST" onsubmit="return confirm('Are you sure you want to delete this article?')">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">
                        <button type="submit" class="bg-barca-red text-white px-4 py-2 rounded-lg font-medium hover:bg-red-800 transition inline-flex items-center">
                            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                            </svg>
                            Delete
                        </button>
                    </form>
                </div>
            <?php endif; ?>
        </div>

        <h1 class="text-4xl font-extrabold text-gray-900 mb-8">
            <?= htmlspecialchars($article['title']) ?>
        </h1>

        <div class="prose prose-lg max-w-none">
            <?= nl2br(htmlspecialchars($article['content'])) ?>
        </div>
    </div>
</article>

<?php require dirname(__DIR__) . '/layouts/footer.php'; ?>
