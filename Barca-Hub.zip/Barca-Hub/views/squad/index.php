<?php require dirname(__DIR__) . '/layouts/header.php'; ?>

<section class="bg-gradient-to-r from-barca-blue to-barca-red py-12">
    <div class="container mx-auto px-4 text-center text-white">
        <h1 class="text-4xl font-extrabold mb-2">First Team Squad</h1>
        <p class="text-white/80">Meet the players representing FC Barcelona</p>
    </div>
</section>

<section class="py-12 container mx-auto px-4">
    <?php 
    $positions = ['Goalkeeper', 'Defender', 'Midfielder', 'Forward'];
    $positionColors = [
        'Goalkeeper' => 'from-yellow-500 to-yellow-600',
        'Defender' => 'from-blue-500 to-blue-600',
        'Midfielder' => 'from-green-500 to-green-600',
        'Forward' => 'from-red-500 to-red-600',
    ];
    ?>
    
    <?php foreach ($positions as $position): ?>
        <?php if (!empty($groupedPlayers[$position])): ?>
            <div class="mb-12">
                <div class="flex items-center mb-6">
                    <div class="w-2 h-8 bg-gradient-to-b <?= $positionColors[$position] ?> rounded-full mr-4"></div>
                    <h2 class="text-2xl font-bold text-gray-800"><?= $position ?>s</h2>
                </div>
                
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    <?php foreach ($groupedPlayers[$position] as $player): ?>
                        <div class="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition group">
                            <div class="h-48 bg-gradient-to-br from-barca-blue to-barca-red flex items-center justify-center relative">
                                <?php if (!empty($player['image_url'])): ?>
                                    <img src="<?= htmlspecialchars($player['image_url']) ?>" alt="<?= htmlspecialchars($player['name']) ?>" class="w-full h-full object-cover">
                                <?php else: ?>
                                    <div class="text-center text-white">
                                        <div class="text-6xl font-black opacity-50"><?= $player['kit_number'] ?></div>
                                    </div>
                                <?php endif; ?>
                                <div class="absolute top-4 left-4 w-12 h-12 bg-barca-gold rounded-full flex items-center justify-center shadow-lg">
                                    <span class="text-barca-blue font-black text-lg"><?= $player['kit_number'] ?></span>
                                </div>
                            </div>
                            <div class="p-5">
                                <h3 class="text-lg font-bold text-gray-800 group-hover:text-barca-blue transition">
                                    <?= htmlspecialchars($player['name']) ?>
                                </h3>
                                <p class="text-sm text-gray-500"><?= htmlspecialchars($player['position']) ?></p>
                                <?php if (!empty($player['nationality'])): ?>
                                    <p class="text-xs text-gray-400 mt-1"><?= htmlspecialchars($player['nationality']) ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    <?php endforeach; ?>
    
    <?php if (empty($players)): ?>
        <div class="text-center py-16 text-gray-500">
            <svg class="w-24 h-24 mx-auto mb-6 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
            </svg>
            <h3 class="text-xl font-semibold text-gray-600 mb-2">No players in the squad yet</h3>
            <p class="text-gray-400">Player data will be displayed here once added to the database.</p>
        </div>
    <?php endif; ?>
</section>

<?php require dirname(__DIR__) . '/layouts/footer.php'; ?>
