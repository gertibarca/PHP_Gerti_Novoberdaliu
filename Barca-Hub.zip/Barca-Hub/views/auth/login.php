<?php require dirname(__DIR__) . '/layouts/header.php'; ?>

<section class="py-16 container mx-auto px-4">
    <div class="max-w-md mx-auto">
        <div class="text-center mb-8">
            <div class="w-20 h-20 bg-gradient-to-br from-barca-blue to-barca-red rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                <svg viewBox="0 0 100 100" class="w-14 h-14">
                    <circle cx="50" cy="50" r="48" fill="#A50044"/>
                    <circle cx="50" cy="50" r="40" fill="#004D98"/>
                    <text x="50" y="58" text-anchor="middle" fill="white" font-size="24" font-weight="bold">FCB</text>
                </svg>
            </div>
            <h1 class="text-3xl font-extrabold text-gray-900">Welcome Back</h1>
            <p class="text-gray-600 mt-2">Sign in to your Barça fan account</p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl p-8">
            <form action="/login" method="POST">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">
                <div class="mb-6">
                    <label for="email" class="block text-sm font-semibold text-gray-700 mb-2">Email Address</label>
                    <input type="email" id="email" name="email" required
                        class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-barca-blue focus:ring-2 focus:ring-barca-blue/20 outline-none transition"
                        placeholder="your@email.com">
                </div>

                <div class="mb-6">
                    <label for="password" class="block text-sm font-semibold text-gray-700 mb-2">Password</label>
                    <input type="password" id="password" name="password" required
                        class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-barca-blue focus:ring-2 focus:ring-barca-blue/20 outline-none transition"
                        placeholder="Enter your password">
                </div>

                <button type="submit" class="w-full bg-gradient-to-r from-barca-blue to-barca-red text-white py-3 rounded-lg font-bold hover:opacity-90 transition shadow-lg">
                    Sign In
                </button>
            </form>

            <div class="mt-6 text-center">
                <p class="text-gray-600">
                    Don't have an account? 
                    <a href="/register" class="text-barca-blue font-semibold hover:text-barca-red transition">Join the Culés</a>
                </p>
            </div>
        </div>
    </div>
</section>

<?php require dirname(__DIR__) . '/layouts/footer.php'; ?>
