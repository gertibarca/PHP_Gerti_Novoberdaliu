<?php require dirname(__DIR__) . '/layouts/header.php'; ?>

<section class="bg-gradient-to-br from-barca-blue via-barca-blue to-barca-red py-20">
    <div class="container mx-auto px-4 text-center text-white">
        <h1 class="text-5xl md:text-6xl font-extrabold mb-4 tracking-tight">
            Més Que Un Project
        </h1>
        <p class="text-xl md:text-2xl text-white/90 max-w-2xl mx-auto mb-8">
            Your ultimate FC Barcelona fan portal. Live matches, squad updates, and the latest news from Camp Nou.
        </p>
        <div class="flex flex-wrap justify-center gap-4">
            <a href="/matches" class="bg-barca-gold text-barca-blue px-8 py-3 rounded-lg font-bold text-lg hover:bg-yellow-400 transition shadow-lg">
                View Matches
            </a>
            <a href="/squad" class="bg-white/10 backdrop-blur text-white px-8 py-3 rounded-lg font-bold text-lg hover:bg-white/20 transition border border-white/30">
                Meet the Squad
            </a>
        </div>
    </div>
</section>

<section class="py-16 container mx-auto px-4">
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div class="bg-white rounded-2xl shadow-xl overflow-hidden">
            <div class="bg-gradient-to-r from-barca-blue to-barca-red px-6 py-4">
                <h2 class="text-xl font-bold text-white flex items-center">
                    <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                    </svg>
                    Next Fixture
                </h2>
            </div>
            <div class="p-6">
                <?php if ($nextMatch): ?>
                    <div class="text-center">
                        <p class="text-sm text-gray-500 mb-2"><?= htmlspecialchars($nextMatch['competition']) ?></p>
                        <div class="flex items-center justify-center space-x-6 my-6">
                            <div class="text-center">
                                <div class="w-16 h-16 bg-gradient-to-br from-barca-blue to-barca-red rounded-full flex items-center justify-center mb-2">
                                    <span class="text-white font-bold text-lg">FCB</span>
                                </div>
                                <p class="font-semibold">Barcelona</p>
                            </div>
                            <div class="text-3xl font-bold text-gray-400">VS</div>
                            <div class="text-center">
                                <div class="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center mb-2">
                                    <span class="text-gray-600 font-bold text-sm"><?= strtoupper(substr($nextMatch['opponent'], 0, 3)) ?></span>
                                </div>
                                <p class="font-semibold"><?= htmlspecialchars($nextMatch['opponent']) ?></p>
                            </div>
                        </div>
                        <div class="bg-gray-50 rounded-lg p-4">
                            <p class="text-lg font-semibold text-barca-blue">
                                <?= date('l, F j, Y', strtotime($nextMatch['match_date'])) ?>
                            </p>
                            <p class="text-gray-600"><?= htmlspecialchars($nextMatch['venue']) ?></p>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="text-center py-8 text-gray-500">
                        <svg class="w-16 h-16 mx-auto mb-4 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                        </svg>
                        <p>No upcoming fixtures scheduled</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="bg-white rounded-2xl shadow-xl overflow-hidden">
            <div class="bg-gradient-to-r from-barca-red to-barca-blue px-6 py-4">
                <h2 class="text-xl font-bold text-white flex items-center">
                    <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                    Recent Results
                </h2>
            </div>
            <div class="p-6">
                <?php if (!empty($recentResults)): ?>
                    <div class="space-y-4">
                        <?php foreach ($recentResults as $match): ?>
                            <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition">
                                <div class="flex items-center space-x-3">
                                    <span class="font-semibold">Barcelona</span>
                                    <span class="text-lg font-bold <?= $match['home_score'] > $match['away_score'] ? 'text-green-600' : ($match['home_score'] < $match['away_score'] ? 'text-red-600' : 'text-gray-600') ?>">
                                        <?= $match['home_score'] ?> - <?= $match['away_score'] ?>
                                    </span>
                                    <span class="font-semibold"><?= htmlspecialchars($match['opponent']) ?></span>
                                </div>
                                <span class="text-sm text-gray-500"><?= date('M j', strtotime($match['match_date'])) ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-8 text-gray-500">
                        <p>No recent results available</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<section class="py-16 bg-gray-100">
    <div class="container mx-auto px-4">
        <div class="flex items-center justify-between mb-8">
            <h2 class="text-3xl font-bold text-gray-800">Latest News</h2>
            <a href="/news" class="text-barca-blue hover:text-barca-red font-semibold transition">
                View All News →
            </a>
        </div>
        
        <?php if (!empty($latestNews)): ?>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <?php foreach ($latestNews as $article): ?>
                    <article class="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition group">
                        <div class="h-48 bg-gradient-to-br from-barca-blue to-barca-red flex items-center justify-center">
                            <?php if (!empty($article['image_url'])): ?>
                                <img src="<?= htmlspecialchars($article['image_url']) ?>" alt="" class="w-full h-full object-cover">
                            <?php else: ?>
                                <svg class="w-16 h-16 text-white/50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"/>
                                </svg>
                            <?php endif; ?>
                        </div>
                        <div class="p-6">
                            <p class="text-sm text-gray-500 mb-2"><?= date('F j, Y', strtotime($article['created_at'])) ?></p>
                            <h3 class="text-lg font-bold text-gray-800 mb-2 group-hover:text-barca-blue transition">
                                <?= htmlspecialchars($article['title']) ?>
                            </h3>
                            <p class="text-gray-600 text-sm mb-4">
                                <?= htmlspecialchars($article['excerpt'] ?? substr(strip_tags($article['content']), 0, 120)) ?>...
                            </p>
                            <a href="/news/<?= $article['id'] ?>" class="text-barca-red font-semibold hover:text-barca-blue transition">
                                Read More →
                            </a>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="text-center py-12 text-gray-500">
                <svg class="w-16 h-16 mx-auto mb-4 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"/>
                </svg>
                <p>No news articles yet</p>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php require dirname(__DIR__) . '/layouts/footer.php'; ?>
