<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/vendor/autoload.php';

use Dotenv\Dotenv;
use App\Core\Router;
use App\Controllers\HomeController;
use App\Controllers\MatchController;
use App\Controllers\SquadController;
use App\Controllers\NewsController;
use App\Controllers\AuthController;

$dotenv = Dotenv::createImmutable(dirname(__DIR__));
$dotenv->safeLoad();

session_start();

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

$router = new Router();

$router->get('/', [HomeController::class, 'index']);

$router->get('/matches', [MatchController::class, 'index']);

$router->get('/squad', [SquadController::class, 'index']);

$router->get('/news', [NewsController::class, 'index']);
$router->get('/news/create', [NewsController::class, 'create']);
$router->post('/news/store', [NewsController::class, 'store']);
$router->get('/news/{id}', [NewsController::class, 'show']);
$router->get('/news/{id}/edit', [NewsController::class, 'edit']);
$router->post('/news/{id}/update', [NewsController::class, 'update']);
$router->post('/news/{id}/delete', [NewsController::class, 'delete']);

$router->get('/login', [AuthController::class, 'loginForm']);
$router->post('/login', [AuthController::class, 'login']);
$router->get('/register', [AuthController::class, 'registerForm']);
$router->post('/register', [AuthController::class, 'register']);
$router->get('/logout', [AuthController::class, 'logout']);

try {
    $router->dispatch();
} catch (Exception $e) {
    http_response_code(500);
    if ($_ENV['APP_DEBUG'] ?? false) {
        echo '<h1>Error</h1><pre>' . htmlspecialchars($e->getMessage()) . '</pre>';
        echo '<pre>' . htmlspecialchars($e->getTraceAsString()) . '</pre>';
    } else {
        echo '<h1>Something went wrong</h1><p>Please try again later.</p>';
    }
}
